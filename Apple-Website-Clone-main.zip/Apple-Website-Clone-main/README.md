# apple.com
In this project, I tried to clone Apple's official website using HTML, CSS and JavaScript. 
[Link to website](https://fidalmathew.github.io/apple.com/)

The website is fully responsive and I've also added some functionality to the bag icon, just as it is present in the original website.

Thanks for reading, any suggestions for improvement will be highly appreciated. 

[![Screenshot-2021-11-28-at-19-56-53-apple-com.png](https://i.postimg.cc/tC38KPnD/Screenshot-2021-11-28-at-19-56-53-apple-com.png)](https://postimg.cc/HVLS5r27)

[![Screenshot-2021-11-28-at-19-57-55-apple-com.png](https://i.postimg.cc/ZYFbkZ5h/Screenshot-2021-11-28-at-19-57-55-apple-com.png)](https://postimg.cc/grjFRChM)